package exceptions;

public class UnsupportedTimeException extends Exception {

	public UnsupportedTimeException() {
		super();
	}
}
