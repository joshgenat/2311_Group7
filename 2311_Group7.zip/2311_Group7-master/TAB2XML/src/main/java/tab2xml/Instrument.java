package tab2xml;

import org.w3c.dom.Element;

public class Instrument {

	
	static String Guitar (String instrument) {
		
			return "<part-name>" + instrument + "</part-name>";
		
	}
}
