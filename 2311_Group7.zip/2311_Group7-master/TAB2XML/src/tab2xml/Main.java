package tab2xml;

import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		
		
        GUI test = new GUI();
		
	}
}
		
